"""Packaged assets for docx2shelf."""
