"""XHTML/XML templates for docx2shelf."""
